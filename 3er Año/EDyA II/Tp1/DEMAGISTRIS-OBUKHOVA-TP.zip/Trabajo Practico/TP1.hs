{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE FunctionalDependencies #-}

import Data.List hiding(words)
import Data.Char hiding(words)
import Prelude hiding (words)

data TTree k v = Node k (Maybe v) (TTree k v) (TTree k v) (TTree k v)
                | Leaf k v
                | E
                deriving Show




search :: Ord k => [k] -> TTree k v -> Maybe v


t = (Node 'r' Nothing E (Node 'e' (Just 16) (Node 'a' Nothing E (Leaf 's' 1) E)(Node 'o' (Just 2) (Leaf 'd' 9) E (Leaf 's' 4)) E) (Node 's' Nothing E (Node 'i' (Just 4) (Leaf 'e' 8)(Leaf 'n' 7) E) E))


search (x:xs) E = Nothing

search (x:xs) (Leaf k v) = if xs == [] then (if x == k then Just v else Nothing) else Nothing 

search (x:xs) (Node a y t1 t2 t3) | xs == [] = (if x == a then y else Nothing)
                                  | x == a     = search xs t2                
                                  | x > a      = search (x:xs) t3            
                                  | otherwise  = search (x:xs) t1            


insert' :: Ord k => [k] -> v -> TTree k v -> TTree k v

insert' (x:xs) a E | xs == [] = Leaf x a
                   | otherwise = (Node x Nothing E (insert' xs a E) E)

insert' (x:xs) a (Leaf k v) | x == k = if xs == [] then (Leaf k a) else (Node k (Just v) E (insert' xs a E) E)
                            | x > k = (Node k (Just v) E E (insert' (x:xs) a E))
                            | otherwise = (Node k (Just v) (insert' (x:xs) a E) E E)

insert' (x:xs) a (Node k v t1 t2 t3) | x == k = if xs == [] then (Node k (Just a) t1 t2 t3) else (Node k v t1 (insert' xs a t2) t3)
                                     | x > k = (Node k v t1 t2 (insert' (x:xs) a t3))
                                     | otherwise = (Node k v (insert' (x:xs) a t1) t2 t3)


delete' :: Ord k => [k] -> TTree k v -> TTree k v

delete' (x:xs) E = E

delete' (x:xs) (Leaf k v) | x == k = if xs == [] then E else (Leaf k v)
                          | otherwise = (Leaf k v)

delete' (x:xs) (Node k v t1 t2 t3) | x == k = if xs == [] then (Node k Nothing t1 t2 t3) else (Node k v t1 (delete' xs t2) t3)
                                   | x > k = (Node k v t1 t2 (delete' (x:xs) t3))
                                   | otherwise = (Node k v (delete' (x:xs) t1) t2 t3)

keys :: Eq v => TTree k v -> [[k]]
keys  E  = [[]]

keys (Leaf x y) = [[x]]

keys (Node c y i E r) | not (isEmpty i) && (isEmpty r) = (keys i) ++ [[c]]
                      | isEmpty i && not (isEmpty r)   = [[c]] ++ (keys r) 
                      | otherwise                      = (keys i) ++ [[c]] ++ (keys r)   

keys (Node c y i m r)  | isEmpty i && isEmpty r       = if y /= Nothing  
                                                            then [[c]] ++ (words [c] m)
                                                            else words [c] m      
                          
                       | not (isEmpty i) && isEmpty r = if y /= Nothing  
                                                            then (keys i) ++ [[c]] ++ (words [c] m)
                                                            else (keys i) ++ (words [c] m)  
  
                       | isEmpty i && not (isEmpty r) = if y /= Nothing  
                                                            then [[c]] ++ (words [c] m) ++ (keys r)
                                                            else (words [c] m) ++ (keys r)

                       | otherwise                    = if y /= Nothing  
                                                            then (keys i) ++ [[c]] ++ (words [c] m) ++ (keys r) 
                                                            else (keys i) ++ (words [c] m) ++ (keys r)





words :: Eq v => [k] -> TTree k v -> [[k]]
words c' (Leaf a b) = [c'++[a]]

words c' (Node c y i E r) | not (isEmpty i) && isEmpty r = (words c' i) ++ [c' ++ [c]]
                          | isEmpty i && not (isEmpty r) = [c'] ++ (words c' r) 
                          | otherwise                    = (words c' i) ++ [c' ++ [c]] ++ (words c' r) 

words c' (Node c y i m r) | isEmpty i && isEmpty r       = if y /= Nothing  
                                                              then [c' ++ [c]] ++ (words (c' ++ [c]) m)
                                                              else words (c' ++ [c]) m                  
                          | not (isEmpty i) && isEmpty r = if y /= Nothing  
                                                              then (words c' i) ++ [c' ++ [c]] ++ (words (c' ++ [c]) m)
                                                              else (words c' i) ++ (words (c' ++ [c]) m)  
                          | isEmpty i && not (isEmpty r) = if y /= Nothing  
                                                              then [c' ++ [c]] ++ (words (c' ++ [c]) m) ++ (words c' r)
                                                              else (words (c' ++ [c]) m) ++ (words c' r)
                          | otherwise                    = if y /= Nothing  
                                                              then (words c' i) ++ [c' ++ [c]] ++ (words (c' ++ [c]) m) ++ (words c' r)
                                                              else (words c' i) ++ (words (c' ++ [c]) m) ++ (words c' r)  
                          
isEmpty :: TTree k v -> Bool

isEmpty E = True
isEmpty _ = False


class Dic k v d | d -> k v where
  vacio :: d
  insertar :: Ord k => k -> v -> d -> d
  buscar   :: Ord k => k -> d -> Maybe v
  eliminar :: Ord k => k -> d -> d
  claves   :: Ord k => d -> [k]

instance (Ord k, Eq v) => Dic [k] v (TTree k v) where
  vacio          = E
  insertar k v d = insert' k v d
  buscar k d     = search k d
  eliminar k d   = delete' k d
  claves d       = keys d